new SimpleBar(document.querySelector('.scroll-inside'), {
    autoHide: false
});